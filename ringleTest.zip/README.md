# 개발환경

React.js 18.2
Typescript4.4.2

# 실행방법
npm i
npm start



